import pymem
import time

class BannerHack:
    def __init__(self, process_name):
        try:
            self.pm = pymem.Pymem(process_name)
            self.module_base = pymem.process.module_from_name(self.pm.process_handle, process_name).lpBaseOfDll
            print(f"[+] Attached to {process_name} | Base Address: {hex(self.module_base)}")
        except Exception as e:
            print(f"[ERROR] Failed to attach to process: {e}")
            self.pm = None

    def force_5_star_pull(self, banner_address):
        if self.pm:
            pull_count = self.pm.read_int(banner_address)
            if pull_count % 10 == 0:
                self.pm.write_int(banner_address, 5) 
                print("[+] 5⭐ Pull Guaranteed!")
            else:
                print("[INFO] Pulling normally...")
            time.sleep(1)

    def start(self):
        print("[+] Gacha Manipulation Enabled!")
        while True:
            self.force_5_star_pull(0xABCDEF12)
            time.sleep(0.5)
