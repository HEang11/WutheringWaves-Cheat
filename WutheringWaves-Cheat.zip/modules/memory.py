# Memory manipulation module
import pymem

class MemoryEditor:
    def __init__(self, process_name):
        self.pm = pymem.Pymem(process_name)

    def read_int(self, address):
        return self.pm.read_int(address)

    def write_int(self, address, value):
        self.pm.write_int(address, value)
