import modules.banner as banner_hack

if __name__ == "__main__":
    print("[+] Starting Wuthering Waves Cheat...")
    hack = banner_hack.BannerHack("GameProcess.exe")  # Replace with actual process name
    hack.start()
